Invoke-WebRequest -Uri "https://github.com/Johven/ANG_FILES/raw/main/angcoin-qt-windows.zip"

Start-Sleep -s 15

Expand-Archive -LiteralPath "$HOME\Downloads\angcoin-qt-windows.zip" -DestinationPath "$HOME\Desktop\ANGCOIN"

$ConfigFile = "rpcuser=rpc_angcoin
rpcpassword=dR2oBQ3K1zYMZQtJFZeAerhWxaJ5Lqeq9J2
rpcbind=0.0.0.0
rpcallowip=127.0.0.1
listen=1
server=1
addnode=node1.angcoin.org"

New-Item -Path "$env:appdata" -Name "ANGCOIN" -ItemType "directory"
New-Item -Path "$env:appdata\ANGCOIN" -Name "ANGCOIN.conf" -ItemType "file" -Value $ConfigFile

$MineBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
echo Press [CTRL+C] to stop mining.
:begin
 for /f %%i in ('angcoin-cli.exe getnewaddress') do set WALLET_ADDRESS=%%i
 angcoin-cli.exe generatetoaddress 1 %WALLET_ADDRESS%
goto begin"

New-Item -Path "$HOME\Desktop\ANGCOIN" -Name "mine.bat" -ItemType "file" -Value $MineBat

Start-Process "$HOME\Desktop\ANGCOIN\angcoin-qt.exe"

Start-Sleep -s 15

Set-Location "$HOME\Desktop\ANGCOIN\"
Start-Process "mine.bat"